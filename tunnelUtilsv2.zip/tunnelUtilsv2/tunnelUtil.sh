var=`sysctl -n machdep.cpu.brand_string`
if [[ $var == *"Apple"* ]]; then
  echo "It's Apple CPU!"
sudo cp /opt/homebrew/bin/socat /usr/local/bin/socat
fi

sudo cp com.pcloudyrelay.plist /Library/LaunchDaemons/
sudo launchctl unload /Library/LaunchDaemons/com.pcloudyrelay.plist
sudo chmod 777 ./pcloudyrelay
sudo cp ./pcloudyrelay /usr/local/bin/
sudo launchctl load /Library/LaunchDaemons/com.pcloudyrelay.plist
